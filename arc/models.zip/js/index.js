const details = document.querySelectorAll("details");

function toggleOpen() {
  if (this.open) {
    return;
    // if the user tries to close the existing open element
  }
  
  for (i = 0; i < details.length; ++i) {
    if(details[i].open) {
      details[i].removeAttribute("open");
      // close the already open details element
    }
  }
}

details.forEach(detail => detail.addEventListener('click', toggleOpen));