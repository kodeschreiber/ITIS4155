A Pen created at CodePen.io. You can find this one at https://codepen.io/marcobiedermann/pen/gReMQy.

 High performance sticky header with shadow on scroll.